﻿# script to create a TFS project


. $PSScriptRoot/NewTeamProjectRequest.ps1


Import-Module ActiveDirectory

Write-Host "Validating request"

# check users before moving foward
foreach ($teamGroup in $teamGroups) {
    Write-Host "--- $( $teamGroup.Name ) ---"
    foreach ($user in $teamGroup.Members) {
        $domain,$samAccountName = $user -split '\\'
        try {
            $account = $null
            $account = Get-ADUser -Identity $samAccountName -Server "$domain.local" -Properties DisplayName,DistinguishedName,SamAccountName
            #out
            Write-Host "   $( (($account.DistinguishedName -split ',')[-2] -split '=')[1] )\$( $account.SamAccountName ) = $( $account.DisplayName )"
        } catch {
            Write-Error "   $user is undetermined"
        }#try
    }
}

$tfsURL = "http://tfsserver:8080/tfs"
$collectionURL = "$tfsURL/$collection"
$tfsOUpath = "CN=Groups,OU=TeamFoundation Server,DC=domain,DC=local"
$collectionOUpath = "OU=$collection,$tfsOUpath"
$TFSSecurity = "${env:ProgramFiles(x86)}\Microsoft Visual Studio 12.0\Common7\IDE\TFSSecurity.exe"
$TFPT = "${env:ProgramFiles(x86)}\Microsoft Team Foundation Server 2013 Power Tools\tfpt.exe"

if ($versionControl -eq 'Git') {
    $sourceControlParam = 'None'
} else {
    $sourceControlParam = 'New'
}

# check for errors
& $TFPT createteamproject /validate /collection:$collectionURL "/teamproject:$teamproject" /processtemplate:$processtemplate /sourcecontrol:$sourceControlParam /verbose /noportal #/noreports
$succeeded = $?

Write-Host "About to create project $teamproject in $collectionURL, sourcecontrol:$sourceControlParam"
Read-Host "Press RETURN to proceed"

# Create TSF project
if ($succeeded) {
    & $TFPT createteamproject /collection:$collectionURL "/teamproject:$teamproject" /processtemplate:$processtemplate /sourcecontrol:$sourceControlParam /verbose /noportal #/noreports
}

if ($versionControl -eq 'Git') {
    $PSScriptRoot/TfsGitAdmin.exe $tfsURL "$collection" "$teamproject"
}#if


# create OU
$collectionOU = Get-ADOrganizationalUnit $collectionOUpath -ErrorAction SilentlyContinue
if ($collectionOU -eq $null) {
    $collectionOU = New-ADOrganizationalUnit -Name $collection -Path $tfsOUpath -PassThru    
}
$projectOU = Get-ADOrganizationalUnit "OU=$teamproject,$collectionOUpath" -ErrorAction SilentlyContinue
if ($projectOU -eq $null) {
    $projectOU = New-ADOrganizationalUnit -Name $teamproject -Path $collectionOUpath -PassThru
}
# Create AD groups
foreach ($teamGroup in $teamGroups) {
    $completeGroupName = "grp_TFS $collectionShort $teamprojectShort Project $($teamGroup.Name)"
    Write-Host "Creating '$completeGroupName'"
    New-ADGroup -Name $completeGroupName -Path $projectOU -GroupScope DomainLocal
    foreach ($user in $teamGroup.Members) {
        $domain,$samAccountName = $user -split '\\'
        $account = $null
        $account = Get-ADUser -Identity $samAccountName -Server $domain
        Add-ADGroupMember -Identity $completeGroupName -Members $account
    }#for member
}#for group

Read-Host "Wait for AD replica, press RETURN when ready..."

& "$PSScriptRoot\Sync-TfsIdentity.ps1" $tfsURL

Read-Host "Wait for TFS sync, press RETURN when ready..."

# put AD groups in TFS groups
foreach ($teamGroup in $teamGroups) {
    $completeGroupName = "grp_TFS $collectionShort $teamprojectShort Project $($teamGroup.Name)"
    & $TFSSecurity /g+ "[$teamproject]\$($teamGroup.MapsTo)" "`"DOMAIN\$completeGroupName`"" /collection:$collectionURL
}#for group

# check users have a license
$standardLicensees = Get-ADGroup "grp_TFS_Standard_Licensees"
$fullLicensees = Get-ADGroup "grp_TFS_Full_Licensees"
$teamGroups | foreach { $_.Members | foreach { 
        $domain,$samAccountName = $_ -split '\\'
        $account = $null
        $account = Get-ADUser -Identity $samAccountName -Server $domain -Properties MemberOf
        if ($account) {
            # BUG these test fail for non-DOMAIN users
            $standardLicensee = $account.MemberOf -contains $standardLicensees
            $fullLicensee = $account.MemberOf -contains $fullLicensees
            if ($fullLicensee) {
                Write-Host "User $_ has Full license."
            } elseif ($standardLicensee) {
                Write-Host "User $_ has Standard license."
            } else {
                Write-Host "User $_ has no license. Assigning a default Standard level"
                Add-ADGroupMember -Identity "grp_TFS_Standard_Licensees" -Members $account
            }#if
        } else {
            Write-Host "User $_ not found."
        }#if
    }#for member
}#for group


#EOF#