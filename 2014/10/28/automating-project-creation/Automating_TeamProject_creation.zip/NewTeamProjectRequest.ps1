﻿# data to create TFS project with createNewProject.ps1 script

$collection = "DefaultCollection"
$collectionShort = "DefaultCollection"
$teamproject = "My long project name"
$teamprojectShort = "MyProject"
$processtemplate = "Microsoft Visual Studio Scrum 2013.3"
$versionControl = 'TFVC'
# $versionControl = 'Git'

$teamGroups = @(
    @{
        Name = "Admin";
        Members = @('DOMAIN\admin1');
        MapsTo = "Project Administrators";
    },
    @{
        Name = "Contributors";
        Members = @('DOMAIN\dev1','DOMAIN\Matt.dev2');
        MapsTo = "$teamproject Team";
    },
    @{
        Name = "Readers";
        Members = @();
        MapsTo = "Readers";        
    },
    @{
        Name = "Builders";
        Members = @();
        MapsTo = "Build Administrators";        
    }
)

#EOF#