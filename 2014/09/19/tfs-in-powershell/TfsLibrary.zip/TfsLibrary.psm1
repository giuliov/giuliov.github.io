﻿function Get-VisualStudioInstallDir
{
    if ($env:ProgramW6432) {
        # 64 bit
        $registryBase = "HKLM:\SOFTWARE\Wow6432Node\Microsoft"
    } else {
        # 32 bit
        $registryBase = "HKLM:\SOFTWARE\Microsoft"
    }

    # where is Visual Studio?
    if (Test-Path "$registryBase\VisualStudio") {
        $highestVSversion = "{0:N1}" -f (Get-ChildItem -Path "$registryBase\VisualStudio" | Split-Path -Leaf | foreach { $_ -as [double] } | sort -Descending | select -First 1)    
        $vsPath = Get-ItemProperty -Path "$registryBase\VisualStudio\$highestVSversion" -Name InstallDir -ErrorAction SilentlyContinue
        if ($vsPath) {
            $vsPath.InstallDir
        }
    }
}


function Get-TeamFoundationServerInstallPath
{
    # where is Team Foundation Server?
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\TeamFoundationServer") {
        $highestTFSversion = "{0:N1}" -f (Get-ChildItem -Path "HKLM:\SOFTWARE\Microsoft\TeamFoundationServer" | Split-Path -Leaf | foreach { $_ -as [double] } | sort -Descending | select -First 1)
        $tfsPath = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\TeamFoundationServer\$highestTFSversion" -Name InstallPath -ErrorAction SilentlyContinue
        if ($tfsPath) {
            $tfsPath.InstallPath
        }
    }#if
}


function Get-TeamFoundationServerInstalledComponents
{
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\TeamFoundationServer") {
        $highestTFSversion = "{0:N1}" -f (Get-ChildItem -Path "HKLM:\SOFTWARE\Microsoft\TeamFoundationServer" | Split-Path -Leaf | foreach { $_ -as [double] } | sort -Descending | select -First 1)
      Get-ChildItem -Path "HKLM:\SOFTWARE\Microsoft\TeamFoundationServer\$highestTFSversion\InstalledComponents" -ErrorAction SilentlyContinue | where {
          (Get-ItemProperty -Path $_.PSPath -Name IsConfigured -ErrorAction SilentlyContinue).IsConfigured -eq 1
      } | foreach {
          Split-Path -Path $_.PSPath -Leaf
      }#for
    }#if
}


function Get-TeamFoundationPaths()
{
    $tfsPath = Get-TeamFoundationServerInstallPath
    return New-Object PsObject -Property @{
        VSpath = Get-VisualStudioInstallDir;
        TFSPath = $tfsPath;
        TFSToolsPath = if ($tfsPath) { Join-Path $tfsPath -ChildPath 'Tools' } else { $null };
        TFSInstalledComponents = Get-TeamFoundationServerInstalledComponents
    }
}


function Get-TFSCollection(
    [Parameter(Mandatory=$True)]
    [Uri]  $collectionurl,
    [Parameter(Mandatory=$False)]
    [string[]]  $assemblies = @()
)
{
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\TeamFoundationServer") {
        $highestTFSversion = "{0:N1}" -f (Get-ChildItem -Path "HKLM:\SOFTWARE\Microsoft\TeamFoundationServer" | Split-Path -Leaf | foreach { $_ -as [double] } | sort -Descending | select -First 1)
        $tfsClientVersion = ", Version=$highestTFSversion.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a"
        [void][System.Reflection.Assembly]::Load("Microsoft.TeamFoundation.Client"+$tfsClientVersion)
        $assemblies | foreach {
            [void][System.Reflection.Assembly]::Load($_+$tfsClientVersion)
        }#for
        return [Microsoft.TeamFoundation.Client.TfsTeamProjectCollectionFactory]::GetTeamProjectCollection($collectionurl)
    }#if
}


Export-ModuleMember -function *
