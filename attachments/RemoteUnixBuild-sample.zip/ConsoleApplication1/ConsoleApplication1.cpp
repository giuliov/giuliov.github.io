// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


// branch def
int _tmain(int argc, _TCHAR* argv[])
{
	printf("Hello, World!\r\n");
	return 0;
}

