#include <stdio.h>

void main()
{
	printf("Hello Alessio, World!\r\n");
}