cd /tmp/src/UnixSources
cc HelloWorld/hello.c
# etc etc